﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.fvContact.ChangeMode(FormViewMode.Insert);
    }


    protected void fvContact_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            //Response.Write(entry.Key+": "+entry.Value+"<br />");
        }
    }

    protected void SqlDSMessages_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {

    }

    protected void SqlDSMessages_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Contact_ID), 0) +1 From Messages";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Contact_ID", id);
        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            //e.Command.Parameters["@Member_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void fvContact_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                Response.Write("<script> alert('Your Message send to admin!!')</script>");
                //this.fvMembers.ChangeMode(FormViewMode.Insert);
                //lblStatus.Text = "Record inserted successfully.";
                //lblStatus.ForeColor = System.Drawing.Color.Green;
                //lblStatus.Text = "Record inserted successfully.";
                //lblStatus.ForeColor = System.Drawing.Color.Green;
                e.KeepInInsertMode = true;
            }
            else
            {
                //Label status = (Label)fvMembers.FindControl("lblStatus");
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            //Label status = (Label)fvMembers.FindControl("lblStatus");
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }
}