﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employer_ManageJob : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.gvManageJobs.Visible = false;
                this.fvManageJobs.Visible = true;
                this.SqlDSManageJobs.FilterExpression = "Job_ID=" +
                Request.QueryString["id"];
                this.fvManageJobs.DataBind();
                this.fvManageJobs.ChangeMode(FormViewMode.Edit);

            }
        }
        else
        {
            this.fvManageJobs.Visible=true;
            this.fvManageJobs.Width=200;
            this.fvManageJobs.Height = 300;
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.fvManageJobs.Visible = false;
        this.gvManageJobs.Visible = true;
        this.gvManageJobs.AllowPaging = true;
        this.gvManageJobs.Enabled = true;
        
    }
    protected void SqlDSManageJobs_Updating(object sender, SqlDataSourceCommandEventArgs e)
    {

    }
    protected void SqlDSManageJobs_Updated(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 1)
        {
            Response.Write("<script>alert('Job Updated.');</script>");
            this.fvManageJobs.Visible = false;
            this.gvManageJobs.Visible = true;
            this.gvManageJobs.AllowPaging = true;
            this.gvManageJobs.Enabled = true;
        }
        else
        {
            Response.Write("<script>alert('Error');</script>");
        }
    }

    protected void SqlDSManageJobs_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        string eid = Session["ID"].ToString();
        SqlParameter emid = new SqlParameter("@Member_ID", eid);
        e.Command.Parameters.Add(emid);
        
    }
}