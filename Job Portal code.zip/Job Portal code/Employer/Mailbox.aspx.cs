﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employer_Mailbox : System.Web.UI.Page
{
    private Label status;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public void btnCompose_Click(object sender, EventArgs e)
    {
        this.fvMessages.ChangeMode(FormViewMode.Insert); 
    }
        public void send_click(object sender, EventArgs e)
    {
        try
        {
            TextBox  to = (TextBox)this.fvMessages.FindControl("to");
            TextBox from = (TextBox)this.fvMessages.FindControl("from");
            TextBox subject = (TextBox)this.fvMessages.FindControl("subject");
            TextBox body = (TextBox)this.fvMessages.FindControl("body");
           FileUpload  upload = (FileUpload)this.fvMessages.FindControl("upload");

            MailMessage message = new MailMessage(to.Text, from.Text, subject.Text, body.Text);
            if (upload.HasFile)
            {
                HttpFileCollection fc = Request.Files;
                for (int i = 0; i <= fc.Count - 1; i++)
                {
                    HttpPostedFile pf = fc[i];
                    Attachment attach = new Attachment(pf.InputStream, pf.FileName);
                    message.Attachments.Add(attach);
                }
            }
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            client.EnableSsl = true;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("abc@gmail.com", "12345");
            client.Send(message);
            status = (Label)this.fvMessages.FindControl("status");
            status.Text = "message was sent successfully";
        }
        catch (Exception ex)
        {
            status.Text = ex.StackTrace;
        }
    }

    protected void SqlEmail_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        string eid = Session["ID"].ToString();
        SqlParameter emid = new SqlParameter("@Member_ID", eid);
        e.Command.Parameters.Add(emid);
    }

    protected void fvMessages_ItemInserting(object sender, FormViewInsertEventArgs e)
    {

    }

    protected void SqlEmail_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {

    }

    protected void SqlEmail_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {

    }
    protected void fvMessages_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

    }
}