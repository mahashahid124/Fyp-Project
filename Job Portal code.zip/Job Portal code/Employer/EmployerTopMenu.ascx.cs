﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employer_EmployerTopMenu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            User.Text = Session["user"].ToString();
            UserN.Text = Session["user"].ToString();
        }
        else
        {
            Response.Redirect("EmployerLogin.aspx");
        }
    }
}