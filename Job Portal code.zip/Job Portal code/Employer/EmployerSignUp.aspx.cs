﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Collections;
using System.Net;
using System.Net.Mail;
public partial class Employer_EmployerSignUp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.fvEmployers.ChangeMode(FormViewMode.Insert);
        getCities();
    }

    private void getCities()
    {
        DAO dao = new DAO();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " Select * From Cities";
        cmd.Connection = dao.Connection;
        dao.OpenConnection();
        DataTable dt = new DataTable();
        dt.Load(cmd.ExecuteReader());
        dao.CloseConnection();

        DropDownList ddCity = (DropDownList)fvEmployers.FindControl("ddCity");
        ddCity.DataSource = dt;
        ddCity.DataTextField = "City_Name";
        ddCity.DataValueField = "City_ID";
        ddCity.DataBind();

    }
    protected void fvEmployers_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {

            }
            //Response.Write(entry.Key+": "+entry.Value+"<br />");
        }
    }

    protected void SqlDSEmployer_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Member_ID), 0) +1 From Members";
        decimal id = (decimal)dao.ExecuteScalar(sql);

        sql = "Select IsNull(Max(Company_ID), 0) +1 From Companies";
        decimal comid = (decimal)dao.ExecuteScalar(sql);
        
        SqlParameter companyid = new SqlParameter("@Company_ID", comid);
        SqlParameter insertedKey = new SqlParameter("@Member_ID", id);
        string r = "E";
        SqlParameter role= new SqlParameter("@Role", r);
        DropDownList  ddCity = (DropDownList)fvEmployers.FindControl("ddCity");
        SqlParameter ddC = new SqlParameter("@City_ID", ddCity.SelectedItem.Value);

        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(role);
            e.Command.Parameters.Add(insertedKey);
            e.Command.Parameters.Add(companyid);
            e.Command.Parameters.Add(ddC);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    private void insertCompany()
    {
        DAO dao = new DAO();
        String sql = "Select IsNull(Max(Company_ID), 0) +1 From Companies";
        decimal comid = (decimal)dao.ExecuteScalar(sql);

        TextBox companyName = (TextBox)fvEmployers.FindControl("txtCompany");
        string cn = companyName.Text.Trim();


        SqlParameter companyID = new SqlParameter("@Company_ID", comid);
        SqlParameter companyn = new SqlParameter("@Company_Name", cn);
        sql = "INSERT INTO Companies(Company_ID,Company_Name) VALUES" +
            "(@Company_ID,@Company_Name)";
        SqlCommand cmd = new SqlCommand(sql, dao.Connection);
        try
        {

            cmd.Parameters.Add(companyID);
            cmd.Parameters.Add(companyn);
            dao.OpenConnection();
            cmd.ExecuteNonQuery();

        }catch(Exception ex)
        {
            ex.Message.ToString();
        }
        dao.CloseConnection();
    }
    private void insertEmployer()
    {
        DAO dao = new DAO();
        String sql = "Select IsNull(Max(Employer_Profile_ID), 0) +1 From Employer_Profiles";
        decimal eid = (decimal)dao.ExecuteScalar(sql);

        sql = "Select Max(Member_ID) From Members";
        decimal mid = (decimal)dao.ExecuteScalar(sql);

        SqlParameter emid = new SqlParameter("@Employer_Profile_ID", eid);
        SqlParameter memid = new SqlParameter("@Member_ID", mid);
        sql = "INSERT INTO Employer_Profiles(Employer_Profile_ID,Member_ID) VALUES" +
            "(@Employer_Profile_ID,@Member_ID)";
        SqlCommand cmd = new SqlCommand(sql, dao.Connection);
        try
        {
            cmd.Parameters.Add(emid);
            cmd.Parameters.Add(memid);
            dao.OpenConnection();
            cmd.ExecuteNonQuery();

        }
        catch (Exception ex)
        {
            ex.Message.ToString();
        }
        dao.CloseConnection();
    }

    protected void SqlDSEmployer_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {

        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);
        }

        insertCompany();
        insertEmployer();
    }

    protected void fvEmployers_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                verifyEmail();
                //Response.Redirect("EmployerDashboard.aspx");
                e.KeepInInsertMode = true;
            }
            else
            {
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }

    protected void verifyEmail()
    {
        string username = string.Empty;
        string password = string.Empty;

        DAO dao = new DAO();
        try
        {
            string query = "SELECT Member_FName,Member_LName, Member_Password " +
                "FROM Members WHERE Member_Email = @Email";
            SqlCommand cmd = new SqlCommand(query, dao.Connection);
            
            TextBox email = (TextBox)fvEmployers.FindControl("txtEmail");
            string REmail = email.Text.Trim();
            cmd.Parameters.AddWithValue("@Email", REmail);
            dao.OpenConnection();
            SqlDataReader sdr = cmd.ExecuteReader();

            while (sdr.Read() == true)
            {
                username = sdr["Member_FName"].ToString();
                password = sdr["Member_Password"].ToString();
            }

            dao.CloseConnection();

            if (!string.IsNullOrEmpty(password))
            {
                string SEmail = "smartjobportal2022@gmail.com";
                MailMessage mm = new MailMessage(SEmail, REmail);
                mm.Subject = "Verification of Email";
                mm.Body = string.Format("<h2>Verification of E-mail to finish signing up</h2>" +
                    "{1},<br /><br /> " +
                    "Thank you for joining this platform. <br/>" +
                    "Hope this platform" +
                    " will help you in finding or recruiting best candidates for your " +
                    "company. <br/> The email you register is {0}" +
                    "<br /> " +
                    "<h2>Thank You</h2>.</div></body></html>", REmail, username.ToUpper());
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential();
                NetworkCred.UserName = SEmail;
                NetworkCred.Password = "zrduqwvehzfblkah";
                smtp.UseDefaultCredentials = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = NetworkCred;
                smtp.Port = 587;
                try
                {
                    smtp.Send(mm);
                }
                catch (Exception ex)
                {
                    ex.Message.ToString();
                }

                Response.Write("<script>alert('Check your Email for Verification')</script>");

                //lblMessage.ForeColor = System.Drawing.Color.Green;
                //lblMessage.Text = "Check your Email for Verification";
                ////txtEmail.Text = "";

            }
            else
            {
                //Response.Write("<script>alert('Error')</script>");
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = REmail+ " Email address is not correct";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message.ToString());
            Response.Write("<script>alert('Error')</script>");
        }


    }
    protected void fvEmployers_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
}