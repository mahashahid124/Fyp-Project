﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Net;
using System.Net.Mail;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employer_PostJob : System.Web.UI.Page
{
    DAO dao = new DAO();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            this.fvJobs.ChangeMode(FormViewMode.Insert);
            getCities();
        }
        else
        {
            Response.Redirect("EmployerLogin.aspx");
        }
        //getPostions();
        //string s = "HTML, CSS, JS";
        //string[] names = s.Split(',').Select(n => string.Format("'{0}'", n.Trim())).ToArray();
        //string sql = string.Format("insert into Jobs WHERE " +
        //    "Skills IN ({0})", string.Join(",", names));

    }
    private void getCities()
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " Select * From Cities";
        cmd.Connection = dao.Connection;
        dao.OpenConnection();
        DataTable dt = new DataTable();
        dt.Load(cmd.ExecuteReader());
        dao.CloseConnection();
        DropDownList ddCity = (DropDownList)fvJobs.FindControl("ddCity");
        ddCity.DataSource = dt;
        ddCity.DataTextField = "City_Name";
        ddCity.DataValueField = "City_ID";
        ddCity.DataBind();

    }

    [WebMethod]
    public static string[] GetSkills(string prefix)
    {
        List<string> skills = new List<string>();
        using (SqlConnection conn = new SqlConnection())
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["JobPortalConnectionString"]
                .ConnectionString;
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select Skill_Name, Skill_Id from Skills " +
                    "where Skill_Name like @txtSkills + '%' ORDER BY Skill_Name ASC ";
                cmd.Parameters.AddWithValue("@txtSkills", prefix);
                cmd.Connection = conn;
                conn.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        skills.Add(string.Format("{0}", sdr["Skill_Name"]));
                    }
                }
                conn.Close();
            }
        }
        return skills.ToArray();
    }
    protected void Submit(object sender, EventArgs e)
    {
        TextBox skill = (TextBox)fvJobs.FindControl("txtSkills");
        string skills = Request.Form[skill.UniqueID];
        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Name: " +
            skills + "');", true);
    }
    protected void fvJobs_ItemInserting(object sender, FormViewInsertEventArgs e)
    {

        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                e.Cancel = true;
            }
            //Response.Write(entry.Key + ": " + entry.Value + "<br />");
        }
    }

    protected void SqlDSJobs_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Job_ID), 0) +1 From Jobs";
        decimal id = (decimal)dao.ExecuteScalar(sql);

        string eid = Session["ID"].ToString();
        SqlParameter insertedKey = new SqlParameter("@Job_ID", id);
        SqlParameter empid = new SqlParameter("@Current_Employer_ID", eid);

        DropDownList ddC = (DropDownList)fvJobs.FindControl("ddCity");
        SqlParameter ddCity = new SqlParameter("@City_ID", ddC.SelectedItem.Value);
        DropDownList ddP = (DropDownList)fvJobs.FindControl("ddPositions");
        SqlParameter ddPositions = new SqlParameter("@Positions", ddP.SelectedItem.Value);
        DropDownList ddCL = (DropDownList)fvJobs.FindControl("ddCareerLevel");
        SqlParameter ddCareerLevel = new SqlParameter("@Career_Level",
            ddCL.SelectedItem.Value);
        DropDownList ddQ = (DropDownList)fvJobs.FindControl("ddQualification");
        SqlParameter ddQualification = new SqlParameter("@Qualification",
            ddCL.SelectedItem.Value);
        DropDownList ddMinS = (DropDownList)fvJobs.FindControl("ddMinSalary");

        DropDownList ddMaxS = (DropDownList)fvJobs.FindControl("ddMaxSalary");
        SqlParameter ddSalary = new SqlParameter("@Salary",
            ddMinS.SelectedValue + " - " + ddMaxS.SelectedValue);
        DropDownList ddMinEx = (DropDownList)fvJobs.FindControl("ddMinExperience");
        DropDownList ddMaxEx = (DropDownList)fvJobs.FindControl("ddMaxExperience");
        SqlParameter ddExperience = new SqlParameter("@Experience",
             ddMinEx.SelectedValue + " - " + ddMaxEx.SelectedValue);
        try
        {
            e.Command.Parameters.Add(ddCareerLevel);
            e.Command.Parameters.Add(ddCity);
            e.Command.Parameters.Add(ddPositions);
            e.Command.Parameters.Add(insertedKey);
            e.Command.Parameters.Add(ddSalary);
            e.Command.Parameters.Add(ddExperience);
            e.Command.Parameters.Add(empid);
            e.Command.Parameters.Add(ddQualification);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void SqlDSJobs_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);
        }
    }
    protected void fvJobs_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows == 1)
        {
            Response.Write("<script>alert('Job Posted Successfully.');</script>");
            Response.Redirect("EmployerDashboard.aspx");
            e.KeepInInsertMode = true;

            //this.gvJobs.AllowPaging = true;
            //this.gvJobs.Enabled = true;
        }
        else
        {
            Response.Write("<script>alert('An error occurred');</script>");
            e.KeepInInsertMode = true;
        }


    }

}