﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


public class DAO
{
    private string _connectionstring;
    private SqlConnection _connection;
    
    public string ConnectionString
    {
        get
        {
            return _connectionstring;
        }
        set
        {
            _connectionstring = value;
        }
    }

    public SqlConnection Connection
    {
        get { return this._connection; }
        set { this._connection = value; }
    }

    public DAO()
    {

        this._connectionstring
            = System.Configuration.ConfigurationManager.ConnectionStrings["JobPortalConnectionString"].ConnectionString;
        this._connection = new SqlConnection();
        this._connection.ConnectionString = this._connectionstring;
        
    }

    public void OpenConnection()
    {
        if (this._connection.State != ConnectionState.Open) 
            this._connection.Open();
    }

    public void CloseConnection()
    {
        if (this._connection.State != ConnectionState.Closed)
            this._connection.Close();
    }
    
    public object ExecuteScalar(string sql)
    {
        SqlCommand com = new SqlCommand();
        com.Connection = this._connection;
        com.CommandText = sql;
        this.OpenConnection();
          object returnValue = com.ExecuteScalar();
        this.CloseConnection();
        return returnValue;

    }

    public DataTable ExecuteDataTable(string sql)
    {
        SqlCommand com = new SqlCommand();
        com.Connection = this._connection;
        com.CommandText = sql;
        this.OpenConnection();
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = com;
        DataTable dt = new DataTable();
        da.Fill(dt);
        da.Dispose();
        this.CloseConnection();
        return dt;

    }

    public int ExecuteNonQuery(string sql, Dictionary<string, object> params1)
    {
        SqlCommand com = new SqlCommand();
        com.Connection = this._connection;
        com.CommandText = sql;
        if(params1!=null)
        {
            foreach(KeyValuePair<string,object> kv in params1)
            {
                com.Parameters.AddWithValue(kv.Key, kv.Value);
            }    
        }    
        this.OpenConnection();
        int returnValue = com.ExecuteNonQuery();
        this.CloseConnection();
        return returnValue;

    }

    public int ExecuteNonQuery(string sql, SqlParameterCollection params1)
    {
        SqlCommand com = new SqlCommand();
        com.Connection = this._connection;
        com.CommandText = sql;
        if (params1 != null)
        {
            foreach (SqlParameter p in params1)
            {
                com.Parameters.Add(p);
            }
        }
        this.OpenConnection();
        int returnValue = com.ExecuteNonQuery();
        this.CloseConnection();
        return returnValue;

    }


}