﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JobSeeker_Profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            this.fvJobSeeker.ChangeMode(FormViewMode.Edit);
            TextBox name = (TextBox)this.fvJobSeeker.FindControl("txtName");
            name.Text = Session["FName"].ToString() + " " + Session["LName"].ToString();
            TextBox email = (TextBox)this.fvJobSeeker.FindControl("txtEmailAddress");
            email.Text = Session["Email"].ToString();
            TextBox mobile = (TextBox)this.fvJobSeeker.FindControl("txtPhone");
            mobile.Text = Session["Mobile"].ToString();
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
        getCities();
    }

    private void getCities()
    {
        DAO dao = new DAO();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " Select * From Cities";
        cmd.Connection = dao.Connection;
        dao.OpenConnection();
        DataTable dt = new DataTable();
        dt.Load(cmd.ExecuteReader());
        dao.CloseConnection();

        DropDownList ddCity = (DropDownList)fvJobSeeker.FindControl("ddCity");
        ddCity.DataSource = dt;
        ddCity.DataTextField = "City_Name";
        ddCity.DataValueField = "City_ID";
        ddCity.DataBind();

    }


    protected void SqlDSJobSeeker_Updating(object sender, SqlDataSourceCommandEventArgs e)
    {

        try
        {
            String mid = Session["ProfileID"].ToString();
            decimal m;
            Decimal.TryParse(mid, out m);
            SqlParameter memberid = new SqlParameter("@Member_ID", m);
            e.Command.Parameters.Add(memberid);
            TextBox em = (TextBox)this.fvJobSeeker.FindControl("txtEmailAddress");
            String ema = em.Text;
            SqlParameter email = new SqlParameter("@Member_Email", ema);
            e.Command.Parameters.Add(email);
            TextBox ph = (TextBox)this.fvJobSeeker.FindControl("txtPhone");
            String pho = ph.Text;
            SqlParameter phone = new SqlParameter("@Member_Contact", pho);
            e.Command.Parameters.Add(phone);
            //TextBox bd = (TextBox)this.fvJobSeeker.FindControl("txtBirthday");
            //String birdate = bd.Text;
            //SqlParameter birthdate = new SqlParameter("@Member_DOB", birdate);
            //e.Command.Parameters.Add(birthdate);

            //TextBox c = (TextBox)this.fvJobSeeker.FindControl("txtCnic");
            //String cn = c.Text;
            //SqlParameter cnic = new SqlParameter("@Member_Cnic", cn);
            //e.Command.Parameters.Add(cnic);


            DropDownList dc = (DropDownList)this.fvJobSeeker.FindControl("ddCity");
            SqlParameter city = new SqlParameter("@City_ID", dc.SelectedItem.Value);
            e.Command.Parameters.Add(city);


            RadioButton rm = (RadioButton)this.fvJobSeeker.FindControl("rdMale");
            RadioButton rfm = (RadioButton)this.fvJobSeeker.FindControl("rdFemale");
            String r;
            if (rm.Checked)
            {
                r = rm.Text;
            }
            else
            {
                r = rfm.Text;
            }
            SqlParameter rd = new SqlParameter("@Member_Gender", r);
            e.Command.Parameters.Add(rd);


        }
        catch
        {

        }
    }


    protected void SqlDSJobSeeker_Updated(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            Response.Write("<script> alert('Your information is updated')</script>");
            this.fvJobSeeker.DataBind();
            this.fvJobSeeker.Visible = true;
        }
        else
        {

            Response.Write("<script> alert('Error information is updated')</script>");
        }
    }


    protected void SqlDSJobSeeker_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        string JSid = Session["ProfileID"].ToString();
        SqlParameter Jid = new SqlParameter("@Member_ID", JSid);
        e.Command.Parameters.Add(Jid);
    }
}