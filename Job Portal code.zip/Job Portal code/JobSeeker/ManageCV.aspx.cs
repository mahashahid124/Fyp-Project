﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JobSeeker_UploadCV : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {

        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        this.fvCV.ChangeMode(FormViewMode.Insert);
    }


    protected void fvCV_ItemInserting(object sender, FormViewInsertEventArgs e)
    {

    }

    protected void SqlDScv_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();

        String Profileid = Session["ProfileID"].ToString();
        decimal p;
        Decimal.TryParse(Profileid, out p);
        SqlParameter pid = new SqlParameter("@profile_id", p);

        string sql = "Select IsNull(Max(CV_ID), 0) +1 From CV";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter cid = new SqlParameter("@CV_ID", id);

        //TextBox cvname = (TextBox)this.fvCV.FindControl("txtCVName"); 
        //string cn = cvname.ToString();
        //SqlParameter cname = new SqlParameter("@CV_Name", cn);

        FileUpload FileUploadCV = (FileUpload)fvCV.FindControl("fuCV");
        string path = string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "\\CVFolder\\");
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        try
        {
            FileUploadCV.SaveAs(Path.Combine(path) + FileUploadCV.FileName);
        }
        catch (Exception ex)
        {
            ex.Message.ToUpper();
        }

        BinaryReader br = new BinaryReader(FileUploadCV.PostedFile.InputStream);
        byte[] content;
        content = br.ReadBytes(FileUploadCV.PostedFile.ContentLength);
        SqlParameter cv = new SqlParameter("@CV_Upload", content);

        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(cid);
            e.Command.Parameters.Add(pid);
            //e.Command.Parameters.Add(cname);
            e.Command.Parameters.Add(cv);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }

    protected void SqlDScv_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {

    }

    protected void fvCV_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {

                Response.Write("<script>alert('CV Uploaded Successfully.');</script>");
            }
            else
            {
                ///lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            //lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }



   
    protected void SqlDScv_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {
        string eid = Session["profileID"].ToString();
        SqlParameter emid = new SqlParameter("@Member_ID", eid);
        e.Command.Parameters.Add(emid);
    }



    protected void gvCV_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string li = e.CommandArgument.ToString();
        decimal id;
        Decimal.TryParse(li, out id);
        string fileName;
        byte[] bytes;
        string constr = ConfigurationManager.ConnectionStrings["JobPortalConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from CV where CV_ID=@Id";
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    sdr.Read();
                    bytes = (byte[])sdr["CV_Upload"];
                    //contentType = sdr["ContentType"].ToString();
                    fileName = sdr["CV_Name"].ToString();
                }
                con.Close();
            }
        }

        if (e.CommandName.Equals("View"))
        {

            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Type", "application/pdf");
            Response.AddHeader("Content-Disposition", "inline");
            Response.BinaryWrite(bytes);
            Response.End();


        }
    }
}