﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JobSeeker_ApplyforJob : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        this.fvApplications.ChangeMode(FormViewMode.Insert);
        TextBox name = (TextBox)this.fvApplications.FindControl("txtName");
        name.Text = Session["FName"].ToString() +" " + Session["LName"].ToString();
        TextBox email = (TextBox)this.fvApplications.FindControl("txtEmail");
        email.Text = Session["Email"].ToString();
        TextBox mobile = (TextBox)this.fvApplications.FindControl("txtMobile");
        mobile.Text = Session["Mobile"].ToString();
        TextBox jobTitle = (TextBox)this.fvApplications.FindControl("txtJobTitle");
        jobTitle.Text = Session["JobTitle"].ToString();
       // txtId.Text = Session["JobId"].ToString();
    }

    protected void fvApplications_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            //Response.Write(entry.Key + ": " + entry.Value + "<br />");
        }
    }


    protected void SqlApplications_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Application_ID), 0) +1 From Applications";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Application_ID", id);

        String Profileid = Session["ProfileID"].ToString();
        decimal p;
        Decimal.TryParse(Profileid,out p);
        SqlParameter pid = new SqlParameter("@profile_id", p);

        String Jobid = Session["JobID"].ToString();
        decimal j;
        Decimal.TryParse(Jobid, out j);
        SqlParameter jid = new SqlParameter("@job_id", Jobid);

        String em = Session["Email"].ToString();
        SqlParameter ema = new SqlParameter("@email", em);

        string mob = Session["Mobile"].ToString();
        SqlParameter mobi = new SqlParameter("@phone", mob);


        FileUpload FileUploadCV = (FileUpload)fvApplications.FindControl("fuCV");
        //string createfolder = Request.PhysicalApplicationPath;
        //System.IO.Directory.CreateDirectory(createfolder);
        //FileUploadCV.SaveAs(Server.MapPath(createfolder + FileUploadCV.PostedFile.FileName));
        //string[] paths = { Request.PhysicalApplicationPath,@"CVs" };
        string path = string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),"\\CVFolder\\");
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        try
        {
            FileUploadCV.SaveAs(Path.Combine(path) + FileUploadCV.FileName);
        }
        catch (Exception ex)
        {
            ex.Message.ToUpper();
        }

        BinaryReader br = new BinaryReader(FileUploadCV.PostedFile.InputStream);
        byte[] content;
        content = br.ReadBytes(FileUploadCV.PostedFile.ContentLength);
        SqlParameter cv = new SqlParameter("@CV", content);
     
        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            e.Command.Parameters.Add(pid);
            e.Command.Parameters.Add(jid);
            e.Command.Parameters.Add(ema);
            e.Command.Parameters.Add(mobi);
            e.Command.Parameters.Add(cv);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }


    protected void SqlApplications_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);

        }
    }
    protected void fvApplications_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                Response.Redirect("ApplicationProcess.aspx");
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }

}