﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Drawing;
public partial class Login : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;

    protected void Page_Load(object sender, EventArgs e)
    {

        con = new SqlConnection("Data Source=DESKTOP-B83U7C5\\SQLEXPRESS;Initial Catalog=JobPortal;Integrated Security=True");
        con.Open();
    }
    protected void SubmitButtonClick(object Sender,EventArgs e)
    {


        string query = "select *  from Members " +
            "where Member_Email=@Email and Member_Password=@Password";

        cmd = new SqlCommand(query, con);

        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

        SqlDataAdapter sqa = new SqlDataAdapter(query, con);
        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            while (dr.Read())
            {
                try
                {
                    Session["user"] = dr["Member_FName"];
                    Session["Password"] = dr["Member_Password"];
                    Session["Email"] = dr["Member_Email"];
                    Session["ProfileID"] = dr["Member_ID"];
                    Session["FName"] = dr["Member_FName"];
                    Session["LName"] = dr["Member_LName"];
                    Session["Mobile"] = dr["Member_Contact"];
                }
                catch (Exception ex)
                {
                    ex.Message.Trim();
                }
                
            }
            //lblCheck.Text = Session["user"].ToString();
            Response.Redirect("Dashboard.aspx");
        }
        else
        {
            lblCheck.Text = " Invalid Email or Password.";
            lblCheck.ForeColor = Color.Red;
        }
        con.Close();
    }
}