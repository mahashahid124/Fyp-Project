﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class JobSeeker_JSTopMenu : System.Web.UI.UserControl
{
    DAO dao;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["user"] != null)
        {
            User.Text = Session["user"].ToString();
            UserN.Text = Session["user"].ToString();
        }
        dao = new DAO();
        getCities();

    }
    private void getCities()
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = " Select * From Cities";
        cmd.Connection = dao.Connection;
        dao.OpenConnection();
        DataTable dt = new DataTable();
        dt.Load(cmd.ExecuteReader());
        dao.CloseConnection();
        DropDownList City =ddCity;
        if (City != null)
        {
            City.DataSource = dt;
            City.DataTextField = "City_Name";
            City.DataValueField = "City_ID";
            City.DataBind();
        }

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        String Title = txtJobTitle.Text;
        String City =ddCity.SelectedValue.Trim();
        Session["JobTitle"] = Title;
        Session["City"] = City;
        Response.Redirect("../SearchJobs.aspx");
    }

}