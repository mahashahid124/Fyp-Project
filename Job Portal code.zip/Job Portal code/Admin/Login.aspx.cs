﻿using System;
using System.Data.SqlClient;
using System.Drawing;

public partial class Admin_Login : System.Web.UI.Page
{
    DAO dao;
    protected void Page_Load(object sender, EventArgs e)
    {
       dao = new DAO();
        txtPassword.Attributes["type"] = "password";
    }


    protected void btnLogin_Click(object sender, EventArgs e)
    {
        dao.OpenConnection();
        string query = "select * from Users1 " +
            "where Last_Name=@Name and Password=@Password";

        SqlCommand cmd = new SqlCommand(query, dao.Connection);

        cmd.Parameters.AddWithValue("@Name", txtName.Text);
        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
        
        SqlDataReader dr = cmd.ExecuteReader();

        if (dr.HasRows)
        {
            Session["user"] = txtName.Text;
            Session["pass"] = txtPassword.Text;
            Response.Redirect("Default.aspx");
        }
        else
        {
            lblInvalid.ForeColor = Color.Red;
            lblInvalid.Text = " Invalid Login.";
        }
        dao.CloseConnection();
    }
}