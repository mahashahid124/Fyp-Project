﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Employers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.gvMembers.Visible = false;
                this.SqlDSMembers.FilterExpression = "Member_ID=" +
                Request.QueryString["id"];
                this.fvMembers.DataBind();
                this.fvMembers.ChangeMode(FormViewMode.Edit);
            }
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvMembers.Visible = true;
        this.gvMembers.AllowPaging = true;
        this.gvMembers.Enabled = true;
        //lblStatus.Text = "";
    }
    protected void SqlDSMembers_Updated(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 1)
        {
            //lblStatus.Text = "Record Updated successfully.";
            Response.Write("<script>alert('Member Profile Approved.');</script>");
            //lblStatus.ForeColor = System.Drawing.Color.Green;
            this.gvMembers.Visible = true;
            this.gvMembers.AllowPaging = true;
            this.gvMembers.Enabled = true;
        }
        else
        {
            //lblStatus.Text = "Error Occured in Approving Profile";
        }
    }


}