﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Admin_Countries : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }

        if (!Page.IsPostBack)
        {
            lblStatus.Text = "";
            if (Request.QueryString["id"] != null)
            {
                this.SqlDSCountries.FilterExpression = "Country_ID=" +
                Request.QueryString["id"];
                this.fvCountries.DataBind();

                this.fvCountries.ChangeMode(FormViewMode.Edit);
                this.gvCountries.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvCountries.Enabled = true;
            }
            this.gvCountries.DataBind();
            this.gvCountries.Visible = true;
        }
    }
    protected void SqlDSCountries_Updating(object sender, SqlDataSourceCommandEventArgs e)
    {
        FileUpload FileUpload1 = (FileUpload)fvCountries.FindControl("FileUpload1");
        //SqlParameter Photo = new SqlParameter("@Flag", SqlDbType.VarChar);
        //Photo.Value = FileUpload1.FileBytes.ToString();
        //e.Command.Parameters.Add(Photo);

        string path = string.Concat(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            "\\FlagImages\\");
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        try
        {
            FileUpload1.SaveAs(Path.Combine(path) + FileUpload1.FileName);
        }
        catch (Exception ex)
        {
            ex.Message.ToUpper();
        }

        //FileStream fr = new FileStream(path, FileMode.Open, FileAccess.Read);
        //int fileLength = (int)fr.Length;
        //byte[] rawdata = new byte[fileLength];
        //fr.Read(rawdata, 0, (int)fileLength);

        BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream);
        byte[] content;
        content = br.ReadBytes(FileUpload1.PostedFile.ContentLength);
        SqlParameter flag = new SqlParameter("@Flag", content);
        e.Command.Parameters.Add(flag);

    }


    protected void gvCountries_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Byte[] bytes;
            DataRowView dr = (DataRowView)e.Row.DataItem;
            try
            {
                if (!Convert.IsDBNull(dr["Flag"]))
                {
                    bytes = (byte[])dr["Flag"];

                    string imageUrl = "data:image/jpg;base64," +
                    Convert.ToBase64String((byte[])dr["Flag"]);
                    (e.Row.FindControl("Flag") as System.Web.UI.WebControls.Image)
                        .ImageUrl = imageUrl;

                    System.Web.UI.WebControls.Image img =
                        (System.Web.UI.WebControls.Image)fvCountries.FindControl("imgFlag");
                    
                    try
                    {
                        if (img!=null)
                        {
                            img.ImageUrl = "data:image/jpg;base64," +
                           Convert.ToBase64String((byte[])dr["Flag"]);
                        }

                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message.ToString());
                    }

                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
    public System.Drawing.Image byteArrayToImage(byte[] byteArrayIn)
    {
        MemoryStream ms = new MemoryStream(byteArrayIn);
        System.Drawing.Image returnImage = System.Drawing.Image.FromStream(ms);
        return returnImage;
    }

    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        this.fvCountries.ChangeMode(FormViewMode.Insert);
        this.btnAddNew.Enabled = false;
        this.gvCountries.Enabled = this.btnAddNew.Enabled;

    }

    #region Inserting

    protected void fvCountries_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                // Use the Cancel property to cancel the 
                // insert operation.
                e.Cancel = true;

                lblStatus.Text += "Please enter a value for the " +
                  entry.Key.ToString() + " field.<br/>";

            }
            //Response.Write(entry.Key + ": " + entry.Value + "<br />");
        }
    }

    protected void SqlDSCountries_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Country_ID), 0) +1 From Countries";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Country_ID", id);
        FileUpload FileUpload1 = (FileUpload)fvCountries.FindControl("FileUpload1");
        string[] paths = { Request.PhysicalApplicationPath };
        FileUpload1.SaveAs(Path.Combine(paths) + FileUpload1.FileName.ToString());
        BinaryReader br = new BinaryReader(FileUpload1.PostedFile.InputStream);

        //FileUpload1.SaveAs(Path.Combine(Request.PhysicalApplicationPath + "/img/")+
        //    FileUpload1.FileName.ToString());
        //flag = "Images/" + FileUpload1.FileName.ToString();
        //SqlParameter flag = new SqlParameter("@Flag", FileUpload1.FileName.ToString());
        byte[] content;
        content = br.ReadBytes(FileUpload1.PostedFile.ContentLength);

        SqlParameter flag = new SqlParameter("@Flag", content);

        //flag.Value = DBNull.Value;
        // cmd.Parameters.Add(imageParameter);
        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            e.Command.Parameters.Add(flag);

            //e.Command.Parameters["@Industry_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }

    protected void SqlDSCountries_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);

        }
    }

    protected void fvCountries_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                lblStatus.Text = "Record inserted successfully.";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                this.gvCountries.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvCountries.Enabled = true;
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }

    #endregion Inserting
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvCountries.AllowPaging = true;
        this.btnAddNew.Enabled = true;
        this.gvCountries.Enabled = true;
        lblStatus.Text = "";
        this.gvCountries.DataBind();
        this.gvCountries.Visible = true;
    }

}