﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Specialized;
using System.Data.Common;

public partial class Admin_Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.SqlDSAdmin.FilterExpression = "Login=" +
                Request.QueryString["id"];
                //this.fvAdmin.DataSource = SqlDSIndustries;
                this.fvAdmin.DataBind();
                this.fvAdmin.ChangeMode(FormViewMode.Edit);

            }

        }
    }
    protected void btnAddNew_Click(object sender, EventArgs e)
    {
        this.fvAdmin.ChangeMode(FormViewMode.Insert);
        this.btnAddNew.Enabled = false;
        this.gvAdmin.Enabled = this.btnAddNew.Enabled;
    }


    protected void fvAdmin_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        foreach (DictionaryEntry entry in e.Values)
        {
            if (entry.Value.Equals(""))
            {
                lblStatus.Text += "Please enter a value for the " +
                  entry.Key.ToString() + " field.<br/>";
            }
            //Response.Write(entry.Key + ": " + entry.Value + "<br />");
        }

    }


    protected void SqlDSAdmin_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DAO dao = new DAO();
        string sql = "Select IsNull(Max(Login), 0) +1 From Users1";
        decimal id = (decimal)dao.ExecuteScalar(sql);
        SqlParameter insertedKey = new SqlParameter("@Login", id);

        try
        {
            //insertedKey.Direction = ParameterDirection.Output;
            e.Command.Parameters.Add(insertedKey);
            //e.Command.Parameters["@Industry_ID"].Value = id;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }


    }

    protected void SqlDSAdmin_Inserted(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.Exception != null)
        {
            Response.Write(e.Exception.Message);

        }
    }


    protected void fvAdmin_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            if (e.AffectedRows == 1)
            {
                lblStatus.Text = "Record inserted successfully.";
                lblStatus.ForeColor = System.Drawing.Color.Green;
                this.gvAdmin.AllowPaging = true;
                this.btnAddNew.Enabled = true;
                this.gvAdmin.Enabled = true;
            }
            else
            {
                lblStatus.Text = "An error occurred during the insert operation.";
                e.KeepInInsertMode = true;
            }
        }
        else
        {
            // Insert the code to handle the exception.
            lblStatus.Text = e.Exception.Message;
            e.ExceptionHandled = true;
            e.KeepInInsertMode = true;
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvAdmin.AllowPaging = true;
        this.btnAddNew.Enabled = true;
        this.gvAdmin.Enabled = true;
    }
    //protected void lnkEdit_Click(object sender, EventArgs e)
    //{
    //    this.fvAdmin.ChangeMode(FormViewMode.Edit);
    //    this.gvAdmin.Enabled = false;
       
    //}

    //protected void fvAdmin_ItemUpdating(object sender, FormViewUpdateEventArgs e)
    //{
    //    // Validate the field values entered by the user. This
    //    // example determines whether the user left any fields
    //    // empty. The names of the empty fields are added to
    //    // an ArrayList object.

    //    // Use the NewValues property to access the new 
    //    // values entered by the user.
    //    ArrayList emptyFieldList = ValidateFields((OrderedDictionary)e.NewValues);

    //    if (emptyFieldList.Count > 0)
    //    {

    //        // The user left some fields empty. Display an error message.

    //        // Use the Keys property to retrieve the key field value.
    //        String keyValue = e.Keys["Login"].ToString();

    //        lblStatus.Text = "You must enter a value for each field of record " +
    //          keyValue + ".<br/>The following fields are missing:<br/><br/>";

    //        // Display the missing fields.
    //        foreach (String value in emptyFieldList)
    //        {
    //            // Use the OldValues property to access the original value
    //            // of a field.
    //            lblStatus.Text += value + " - Original Value = " +
    //              e.OldValues[value].ToString() + "<br />";
    //        }


    //    }
    //    else
    //    {
    //        // The field values passed validation. Clear the
    //        // error message label.
    //        lblStatus.Text = "";
    //        this.gvAdmin.Enabled = true;
    //    }

    //}

    //ArrayList ValidateFields(OrderedDictionary list)
    //{

    //    // Create an ArrayList object to store the
    //    // names of any empty fields.
    //    ArrayList emptyFieldList = new ArrayList();

    //    // Iterate though the field values entered by
    //    // the user and check for an empty field.
    //    foreach (DictionaryEntry entry in list)
    //    {
    //        if (entry.Value.Equals(""))
    //        {
    //            // Add the field name to the ArrayList object.
    //            emptyFieldList.Add(entry.Key.ToString());
    //        }
    //    }

    //    return emptyFieldList;
    //}

    //protected void SqlDSAdmin_Updating(object sender, SqlDataSourceCommandEventArgs e)
    //{
    //    DbCommand command = e.Command;
    //    DbConnection cx = command.Connection;
    //    cx.Open();
    //    DbTransaction tx = cx.BeginTransaction();
    //    command.Transaction = tx;
    //}

    //protected void SqlDSAdmin_Updated(object sender, SqlDataSourceStatusEventArgs e)
    //{
    //    DbCommand command = e.Command;
    //    DbTransaction tx = command.Transaction;

    //    // In this code example the OtherProcessSucceeded variable represents
    //    // the outcome of some other process that occurs whenever the data is 
    //    // updated, and must succeed for the data change to be committed. For 
    //    // simplicity, we set this value to true. 
    //    bool OtherProcessSucceeded = true;

    //    if (OtherProcessSucceeded)
    //    {
    //        tx.Commit();
    //        lblStatus.Text = "The record was updated successfully!";
    //    }
    //    else
    //    {
    //        tx.Rollback();
    //        lblStatus.Text = "The record was not updated.";
    //    }
    //}

    //protected void fvAdmin_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    //{
    //    if (e.Exception == null)
    //    {
    //        // Sometimes an error might occur that does not raise an 
    //        // exception, but prevents the update operation from 
    //        // completing. Use the AffectedRows property to determine 
    //        // whether the record was actually updated. 
    //        if (e.AffectedRows == 1)
    //        {
    //            // Use the Keys property to get the value of the key field.
    //            string keyFieldValue = e.Keys["Login"].ToString();

    //            // Display a confirmation message.
    //            lblStatus.Text = "Record " + keyFieldValue +
    //              " updated successfully. ";

    //        }
    //        else
    //        {
    //            // Display an error message.
    //            lblStatus.Text = "An error occurred during the update operation.";

    //            // When an error occurs, keep the FormView
    //            // control in edit mode.
    //            e.KeepInEditMode = true;
    //        }
    //    }
    //    else
    //    {
    //        // Insert the code to handle the exception.
    //        lblStatus.Text = e.Exception.Message;

    //        // Use the ExceptionHandled property to indicate that the 
    //        // exception has already been handled.
    //        e.ExceptionHandled = true;

    //        e.KeepInEditMode = true;
    //    }

    //}
}