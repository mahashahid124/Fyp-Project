﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_jobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            lblname.Text = Session["user"].ToString();
        }
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["id"] != null)
            {
                this.gvJobs.Visible = false;
                this.SqlDSJobs.FilterExpression = "Job_ID=" +
                Request.QueryString["id"];
                this.fvJobs.DataBind();
                this.fvJobs.ChangeMode(FormViewMode.Edit);          
            }
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        this.gvJobs.Visible = true; 
        this.gvJobs.AllowPaging = true;
        this.gvJobs.Enabled = true;
        lblStatus.Text = "";
    }

    protected void SqlDSJobs_Updated(object sender, 
        SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 1)
        {
            //lblStatus.Text = "Record Updated successfully.";
            Response.Write("<script>alert('Job Approved.');</script>");
            lblStatus.ForeColor = System.Drawing.Color.Green;
            this.gvJobs.Visible = true; 
            this.gvJobs.AllowPaging = true;
            this.gvJobs.Enabled = true;
            
        }
        else
        {
            lblStatus.Text = "Error Occured in Approving Job";
        }
    }

}