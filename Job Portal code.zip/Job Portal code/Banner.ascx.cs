﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class Banner : System.Web.UI.UserControl
{


    //SqlConnection con = new SqlConnection("Data Source=DESKTOP-B83U7C5\\SQLEXPRESS;Initial Catalog=JobPortal;Integrated Security=True");
    //string query = "select * from City";

    protected void Page_Load(object sender, EventArgs e)
    {
        //SqlDataAdapter sda = new SqlDataAdapter(query, con);
        //DataTable data = new DataTable();
        //sda.Fill(data);
        
        //if (!IsPostBack)
        //{
        //    BindDropDownList();
        //}

    }

    void BindDropDownList()
    {
        //SqlDataAdapter sda = new SqlDataAdapter(query, con);
        //DataTable data = new DataTable();
        //sda.Fill(data);
        //DropDownList1.DataSource = data;
        //DropDownList1.DataTextField = "City_Name";
        //DropDownList1.DataValueField = "City_ID";
        //DropDownList1.DataBind();
    }
}